package com.miapp.modelo;

public class Usuario {
    private String id;
    private String nombre;
    // Getters y Setters...
}